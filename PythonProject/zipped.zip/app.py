"""This module is to explain how the json library works."""

# import json

# python_data = {
#     "name": "PraiseGod",
#     "hobby": ["singing", "dancing"],
#     "is_good": True,
#     "age": None,
# }

# json_to_loads = '{"message": "I am the message", "isDelivered": true, "title": null}'

# python_data = json.loads(json_to_loads)
# # json_data = json.dumps(python_data)


# print(python_data)
# # print("PraiseGod")


# with open("data.json", "r") as f:
#     data = json.load(f)

# with open("data2.json", "w") as f:
#     json.dump(python_data, f, indent=2)

# print(data)

# json.dump()
