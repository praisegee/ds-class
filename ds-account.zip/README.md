# Bank Account

### To run this file. Type:

```bash
$ python main.py
```

I am a **normal** _text_

- First
- Second
- Third
